<?php
header('Location: /');
exit;
