<?php

declare(strict_types=1);

namespace JsonSchema\Exception;

interface ExceptionInterface
{
}
